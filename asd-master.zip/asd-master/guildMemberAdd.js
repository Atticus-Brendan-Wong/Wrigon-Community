client.on('guildMemberAdd', member => {
  member.send(
    `Welcome to our server! Please do read rules, ideology and infos. Have fun and enjoy your stay! 😀`
  )
})